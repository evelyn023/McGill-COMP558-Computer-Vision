
for i=7:13
    demo_optical_flow('Backyard',i,i+1);
    pause(.001);
    fprintf('Frame: %d\n',i)
end


